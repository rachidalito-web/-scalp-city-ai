from dataclasses import dataclass
import numpy as np
import pandas as pd
import ccxt

@dataclass
class Vote:
    name: str
    signal: str
    score: float
    confidence: float
    reason: str

def ema(s,n): return s.ewm(span=n,adjust=False).mean()

def rsi(s,n=14):
    d=s.diff()
    up=d.clip(lower=0).ewm(alpha=1/n,adjust=False).mean()
    dn=(-d.clip(upper=0)).ewm(alpha=1/n,adjust=False).mean()
    return (100-100/(1+up/dn.replace(0,np.nan))).fillna(50)

def atr(d,n=14):
    pc=d.close.shift()
    tr=pd.concat([(d.high-d.low).abs(),(d.high-pc).abs(),(d.low-pc).abs()],axis=1).max(axis=1)
    return tr.ewm(alpha=1/n,adjust=False).mean().bfill()

def fetch(symbol, timeframe, limit=350):
    ex=ccxt.binance({"enableRateLimit":True})
    rows=ex.fetch_ohlcv(symbol,timeframe,limit=limit)
    d=pd.DataFrame(rows,columns=["timestamp","open","high","low","close","volume"])
    d["timestamp"]=pd.to_datetime(d.timestamp,unit="ms")
    return d

def agents(d):
    c=float(d.close.iloc[-1]); out=[]
    e20,e50,e200=ema(d.close,20).iloc[-1],ema(d.close,50).iloc[-1],ema(d.close,200).iloc[-1]
    s=float(np.clip(((e20/e50)-1)*80,-1,1))
    out.append(Vote("TREND AI","BUY" if s>.12 else "SELL" if s<-.12 else "WAIT",s,abs(s),f"EMA20/50 • price {'>' if c>e200 else '<'} EMA200"))
    rv=float(rsi(d.close).iloc[-1]); s=float(np.clip((50-rv)/25,-1,1))
    out.append(Vote("RSI AI","BUY" if rv<38 else "SELL" if rv>62 else "WAIT",s,abs(s),f"RSI {rv:.1f}"))
    m=ema(d.close,12)-ema(d.close,26); sig=ema(m,9); h=float(m.iloc[-1]-sig.iloc[-1])
    scale=max(float(d.close.pct_change().std()*c),1); s=float(np.clip(h/scale,-1,1))
    out.append(Vote("MACD AI","BUY" if s>.10 else "SELL" if s<-.10 else "WAIT",s,min(abs(s)*2,1),f"Histogram {h:+.2f}"))
    vr=float(d.volume.iloc[-1]/d.volume.rolling(30).mean().iloc[-1]); direction=np.sign(d.close.iloc[-1]-d.open.iloc[-1]); s=float(np.clip((vr-1)*direction,-1,1))
    out.append(Vote("VOLUME AI","BUY" if s>.15 else "SELL" if s<-.15 else "WAIT",s,min(abs(vr-1),1),f"{vr:.2f}× avg volume"))
    hi=float(d.high.rolling(20).max().iloc[-2]); lo=float(d.low.rolling(20).min().iloc[-2]); s=.8 if c>hi else -.8 if c<lo else 0
    out.append(Vote("BREAKOUT AI","BUY" if s>0 else "SELL" if s<0 else "WAIT",s,abs(s),f"Range {lo:,.0f}–{hi:,.0f}"))
    ret=float(d.close.pct_change(6).iloc[-1]*100); s=float(np.clip(ret/1.2,-1,1))
    out.append(Vote("MOMENTUM AI","BUY" if s>.12 else "SELL" if s<-.12 else "WAIT",s,abs(s),f"6 bars {ret:+.2f}%"))
    av=float(atr(d).iloc[-1]/c*100)
    out.append(Vote("RISK AI","WAIT",0,min(av/1.5,1),f"ATR {av:.2f}%"))
    return out

def master(votes):
    w={"TREND AI":.22,"RSI AI":.14,"MACD AI":.18,"VOLUME AI":.14,"BREAKOUT AI":.16,"MOMENTUM AI":.16}
    raw=sum(v.score*w.get(v.name,0) for v in votes)
    active=[np.sign(v.score) for v in votes if v.name!="RISK AI" and abs(v.score)>.1]
    agree=abs(sum(active))/len(active) if active else 0
    vol=next(v.confidence for v in votes if v.name=="RISK AI")
    score=float(np.clip(raw*(1-.25*vol),-1,1))
    conf=float(np.clip(abs(score)*.75+agree*.25,0,1))
    signal="BUY" if score>.18 else "SELL" if score<-.18 else "WAIT"
    return Vote("MASTER AI",signal,score,conf,f"Consensus {agree*100:.0f}%")

def risk_plan(d,equity,risk_pct,signal):
    p=float(d.close.iloc[-1]); a=float(atr(d).iloc[-1]); dist=max(a*1.5,p*.0035)
    cash=equity*risk_pct/100; qty=cash/dist
    if signal=="SELL": stop,target=p+dist,p-2*dist
    else: stop,target=p-dist,p+2*dist
    return {"price":p,"stop":stop,"target":target,"qty":qty,"risk_cash":cash}
