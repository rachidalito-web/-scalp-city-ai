import time
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from engine import fetch, agents, master, risk_plan, ema

st.set_page_config(page_title="Scalp City AI V2",page_icon="🏙️",layout="wide",initial_sidebar_state="collapsed")
st.markdown("""<style>
header{visibility:hidden}.block-container{padding:.5rem .55rem 5rem}.stApp{background:radial-gradient(circle at 50% -10%,#173b7a,#071126 42%,#02050d 100%);color:#eef7ff}
.title{font-size:30px;font-weight:950}.sub,.small{opacity:.68;font-size:12px}.city{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}
.tower{padding:12px;border-radius:15px;background:linear-gradient(180deg,#102653e8,#050b1be8);border:1px solid #2776ac;min-height:112px}
.buy{border-color:#20d99b}.sell{border-color:#ff4b78}.wait{border-color:#3da8ff}.sig{font-size:22px;font-weight:900}
div[data-testid="stMetric"]{background:#09162fbb;border:1px solid #1c527e;border-radius:14px;padding:8px}
@media(min-width:850px){.city{grid-template-columns:repeat(4,1fr)}}</style>""",unsafe_allow_html=True)

if "cash" not in st.session_state: st.session_state.cash=10000.0
if "position" not in st.session_state: st.session_state.position=None
if "trades" not in st.session_state: st.session_state.trades=[]

st.markdown('<div class="title">🏙️ SCALP CITY AI — V2</div><div class="sub">Multi-agent command center • PAPER TRADING ONLY</div>',unsafe_allow_html=True)

with st.expander("⚙️ CONTROL ROOM"):
    c1,c2=st.columns(2)
    symbol=c1.selectbox("Market",["BTC/USDT","ETH/USDT","SOL/USDT","XRP/USDT"])
    tf=c2.selectbox("Timeframe",["1m","5m","15m","1h"],1)
    risk=st.slider("Risk per trade (%)",.1,2.0,.5,.1)
    auto=st.toggle("Auto refresh (10 sec)",False)
    st.caption("🔒 Live orders zijn uitgeschakeld.")

try:
    d=fetch(symbol,tf)
except Exception as e:
    st.error("Market feed kon niet laden. Probeer opnieuw.")
    st.code(str(e)); st.stop()

votes=agents(d); boss=master(votes); price=float(d.close.iloc[-1])
pos=st.session_state.position
unreal=0
if pos:
    unreal=(price-pos["entry"])*pos["qty"] if pos["side"]=="BUY" else (pos["entry"]-price)*pos["qty"]
equity=st.session_state.cash+unreal
plan=risk_plan(d,equity,risk,boss.signal)

a,b=st.columns(2); a.metric(symbol,f"${price:,.2f}"); b.metric("MASTER",boss.signal,f"{boss.confidence*100:.0f}% confidence")
a,b=st.columns(2); a.metric("PAPER EQUITY",f"${equity:,.2f}",f"{unreal:+,.2f} open P&L"); b.metric("RISK / TRADE",f"${plan['risk_cash']:,.2f}")

cards=[]
for v in votes+[boss]:
    cards.append(f'<div class="tower {v.signal.lower()}"><div class="small">{v.name}</div><div class="sig">{v.signal}</div><b>{v.score:+.2f}</b> · {v.confidence*100:.0f}%<div class="small">{v.reason}</div></div>')
st.markdown('<div class="city">'+''.join(cards)+'</div>',unsafe_allow_html=True)

x=d.tail(120).copy(); x["EMA20"]=ema(x.close,20); x["EMA50"]=ema(x.close,50)
fig=go.Figure([go.Candlestick(x=x.timestamp,open=x.open,high=x.high,low=x.low,close=x.close,name="Price"),
go.Scatter(x=x.timestamp,y=x.EMA20,name="EMA20",line={"width":1}),go.Scatter(x=x.timestamp,y=x.EMA50,name="EMA50",line={"width":1})])
fig.update_layout(template="plotly_dark",height=370,margin=dict(l=2,r=2,t=25,b=2),paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,.1)",xaxis_rangeslider_visible=False,legend=dict(orientation="h"))
st.plotly_chart(fig,use_container_width=True,config={"displayModeBar":False})

st.subheader("🧠 MASTER COMMAND")
st.progress(boss.confidence,text=f"{boss.signal} • confidence {boss.confidence*100:.0f}%")
a,b=st.columns(2); a.metric("STOP",f"${plan['stop']:,.2f}"); b.metric("TARGET",f"${plan['target']:,.2f}")

a,b=st.columns(2)
if a.button("▶ EXECUTE PAPER SIGNAL",type="primary",disabled=boss.signal=="WAIT" or pos is not None):
    st.session_state.position={"side":boss.signal,"entry":price,"qty":plan["qty"]}
    st.session_state.trades.append({"Action":boss.signal,"Price":price,"Qty":plan["qty"],"P&L":0})
    st.rerun()
if b.button("■ CLOSE PAPER POSITION",disabled=pos is None):
    pnl=(price-pos["entry"])*pos["qty"] if pos["side"]=="BUY" else (pos["entry"]-price)*pos["qty"]
    st.session_state.cash+=pnl
    st.session_state.trades.append({"Action":"CLOSE","Price":price,"Qty":pos["qty"],"P&L":pnl})
    st.session_state.position=None; st.rerun()

if pos: st.info(f"OPEN {pos['side']} • {pos['qty']:.6f} {symbol.split('/')[0]} @ ${pos['entry']:,.2f} • P&L ${unreal:+,.2f}")

with st.expander("📡 AGENT VOTING"):
    st.dataframe(pd.DataFrame([{"Agent":v.name,"Signal":v.signal,"Score":round(v.score,2),"Confidence":f"{v.confidence*100:.0f}%","Reason":v.reason} for v in votes+[boss]]),hide_index=True,use_container_width=True)
with st.expander("📒 PAPER TRADE LOG"):
    if st.session_state.trades: st.dataframe(pd.DataFrame(st.session_state.trades),hide_index=True,use_container_width=True)
    else: st.caption("Nog geen trades.")

st.caption("Experimentele software • Geen financieel advies • Test en backtest eerst.")
if auto:
    time.sleep(10); st.rerun()
